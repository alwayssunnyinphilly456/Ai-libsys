import { Request, Response } from 'express';
import { Book } from '../models/Book';

export async function listBooks(_req: Request, res: Response) {
  const books = await Book.find().sort({ created_at: -1 });
  return res.json({ data: books });
}

export async function createBook(req: Request, res: Response) {
  try {
    const book = await Book.create(req.body);
    return res.json({ data: book });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}

export async function updateBook(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const book = await Book.findByIdAndUpdate(id, req.body, { new: true });
    return res.json({ data: book });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}

export async function deleteBook(req: Request, res: Response) {
  try {
    const { id } = req.params;
    await Book.findByIdAndDelete(id);
    return res.json({ success: true });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}