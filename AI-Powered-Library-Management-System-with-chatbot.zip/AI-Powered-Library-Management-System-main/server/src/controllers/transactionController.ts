import { Request, Response } from 'express';
import { Transaction } from '../models/Transaction';
import { Book } from '../models/Book';
import { Member } from '../models/Member';
import { AuthRequest } from '../middleware/auth';

export async function listTransactions(req: AuthRequest, res: Response) {
  try {
    let query: any = {};
    if (req.user?.role === 'user') {
      const member = await Member.findOne({ email: req.user.email });
      if (member) query.member_id = (member as any)._id.toString();
    }
    const transactions = await Transaction.find(query).sort({ created_at: -1 });
    return res.json({ data: transactions });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}

export async function borrowBook(req: AuthRequest, res: Response) {
  try {
    const { book_id, member_id, issued_by, due_date, notes } = req.body;
    const book = await Book.findById(book_id);
    if (!book) return res.status(404).json({ error: 'Book not found' });

    // Resolve member: for users, derive from their email; for admin/staff allow provided member_id
    let member = null as any;
    if (req.user?.role === 'admin' || req.user?.role === 'staff') {
      if (member_id) {
        member = await Member.findById(member_id);
      } else {
        member = await Member.findOne({ email: req.user?.email });
      }
    } else {
      member = await Member.findOne({ email: req.user?.email });
    }
    if (!member) return res.status(404).json({ error: 'Member not found' });

    if (req.user?.role === 'admin' || req.user?.role === 'staff') {
      if (book.available_copies <= 0) return res.status(400).json({ error: 'No available copies' });
      const transaction = await Transaction.create({
        book_id: (book as any)._id.toString(),
        member_id: (member as any)._id.toString(),
        issued_by: issued_by || req.user?.email,
        due_date: new Date(due_date || Date.now() + 14 * 24 * 60 * 60 * 1000),
        status: 'issued',
        notes: notes || undefined,
        issue_date: new Date(),
      });
      book.available_copies = Math.max(0, book.available_copies - 1);
      await book.save();
      return res.json({ data: transaction });
    } else {
      // Regular user: create a request transaction that staff/admin can approve
      const transaction = await Transaction.create({
        book_id: (book as any)._id.toString(),
        member_id: (member as any)._id.toString(),
        issued_by: undefined,
        due_date: new Date(due_date || Date.now() + 14 * 24 * 60 * 60 * 1000),
        status: 'requested',
        notes: notes || undefined,
      });
      return res.json({ data: transaction });
    }
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}

export async function approveBorrow(req: AuthRequest, res: Response) {
  try {
    const { id } = req.params;
    const txn = await Transaction.findById(id);
    if (!txn) return res.status(404).json({ error: 'Transaction not found' });
    if (txn.status !== 'requested') return res.status(400).json({ error: 'Transaction not in requested state' });

    const book = await Book.findById(txn.book_id);
    if (!book) return res.status(404).json({ error: 'Book not found' });
    if (book.available_copies <= 0) return res.status(400).json({ error: 'No available copies' });

    book.available_copies = Math.max(0, book.available_copies - 1);
    await book.save();

    txn.status = 'issued';
    txn.issue_date = new Date();
    txn.due_date = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000);
    txn.issued_by = req.user?.email;
    await txn.save();

    return res.json({ data: txn });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}

export async function returnBook(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const transaction = await Transaction.findById(id);
    if (!transaction) return res.status(404).json({ error: 'Transaction not found' });

    const returnDate = new Date();
    const dueDate = new Date(transaction.due_date);
    const daysOverdue = Math.max(0, Math.floor((returnDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
    const fineAmount = daysOverdue * 2;

    transaction.return_date = returnDate;
    transaction.status = 'returned';
    transaction.fine_amount = fineAmount;
    await transaction.save();

    const book = await Book.findById(transaction.book_id);
    if (book) {
      book.available_copies = book.available_copies + 1;
      await book.save();
    }

    return res.json({ data: transaction });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}