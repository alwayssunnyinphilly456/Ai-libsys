import { Request, Response } from 'express';
import { Member } from '../models/Member';

export async function listMembers(_req: Request, res: Response) {
  const members = await Member.find().sort({ created_at: -1 });
  return res.json({ data: members });
}

export async function updateMember(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const member = await Member.findByIdAndUpdate(id, req.body, { new: true });
    return res.json({ data: member });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}

export async function toggleMemberStatus(req: Request, res: Response) {
  try {
    const { id } = req.params;
    const member = await Member.findById(id);
    if (!member) return res.status(404).json({ error: 'Member not found' });
    member.is_active = !member.is_active;
    await member.save();
    return res.json({ data: member });
  } catch (err: any) {
    return res.status(400).json({ error: err.message });
  }
}