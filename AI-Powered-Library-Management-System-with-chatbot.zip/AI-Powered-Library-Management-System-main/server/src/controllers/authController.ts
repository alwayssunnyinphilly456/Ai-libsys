import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { User } from '../models/User';
import { Member } from '../models/Member';
import { signToken } from '../utils/jwt';

export async function register(req: Request, res: Response) {
  try {
    const { email, password, fullName } = req.body;
    if (!email || !password || !fullName) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const existing = await User.findOne({ email });
    if (existing) return res.status(400).json({ error: 'Email already registered' });

    const passwordHash = await bcrypt.hash(password, 10);
    const user = await User.create({ email, passwordHash, fullName });

    const memberId = `MEM${Date.now().toString().slice(-6)}`;
    await Member.create({
      member_id: memberId,
      full_name: fullName,
      email: email,
      membership_type: 'standard',
      membership_start: new Date(),
      is_active: true,
    });

    const accessToken = signToken({ id: user.id, email: user.email, role: user.role }, '1h');
    return res.json({
      user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role },
      accessToken,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Server error' });
  }
}

export async function login(req: Request, res: Response) {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const match = await bcrypt.compare(password, user.passwordHash);
    if (!match) return res.status(400).json({ error: 'Invalid credentials' });

    const accessToken = signToken({ id: user.id, email: user.email, role: user.role }, '1h');
    return res.json({
      user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role },
      accessToken,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Server error' });
  }
}

export async function me(req: Request, res: Response) {
  try {
    const auth = req.headers.authorization;
    if (!auth) return res.status(401).json({ error: 'Missing Authorization header' });
    const token = auth.replace('Bearer ', '');
    const payload: any = JSON.parse(Buffer.from(token.split('.')[1], 'base64').toString('utf-8'));

    const user = await User.findById(payload.id);
    if (!user) return res.status(404).json({ error: 'User not found' });

    return res.json({ user: { id: user.id, email: user.email, fullName: user.fullName, role: user.role } });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Server error' });
  }
}