import mongoose, { Schema, Document } from 'mongoose';

export interface IBook extends Document {
  isbn?: string;
  title: string;
  author: string;
  publisher?: string;
  publication_year?: number;
  category: string;
  total_copies: number;
  available_copies: number;
  cover_image?: string;
  description?: string;
  created_at: Date;
  updated_at: Date;
}

const BookSchema = new Schema<IBook>({
  isbn: { type: String },
  title: { type: String, required: true },
  author: { type: String, required: true },
  publisher: { type: String },
  publication_year: { type: Number },
  category: { type: String, required: true },
  total_copies: { type: Number, required: true },
  available_copies: { type: Number, required: true },
  cover_image: { type: String },
  description: { type: String },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
});

BookSchema.pre('save', function (next) {
  this.updated_at = new Date();
  next();
});

export const Book = mongoose.model<IBook>('Book', BookSchema);