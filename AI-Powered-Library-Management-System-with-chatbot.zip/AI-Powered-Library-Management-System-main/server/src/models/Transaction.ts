import mongoose, { Schema, Document } from 'mongoose';

export interface ITransaction extends Document {
  book_id: string;
  member_id: string;
  issued_by?: string;
  issue_date: Date;
  due_date: Date;
  return_date?: Date | null;
  status: 'requested' | 'issued' | 'returned' | 'overdue';
  fine_amount: number;
  notes?: string;
  created_at: Date;
}

const TransactionSchema = new Schema<ITransaction>({
  book_id: { type: String, required: true },
  member_id: { type: String, required: true },
  issued_by: { type: String },
  issue_date: { type: Date },
  due_date: { type: Date, required: true },
  return_date: { type: Date },
  status: { type: String, enum: ['requested', 'issued', 'returned', 'overdue'], default: 'issued' },
  fine_amount: { type: Number, default: 0 },
  notes: { type: String },
  created_at: { type: Date, default: Date.now },
});

export const Transaction = mongoose.model<ITransaction>('Transaction', TransactionSchema);