import mongoose, { Schema, Document } from 'mongoose';

export interface IMember extends Document {
  member_id: string;
  full_name: string;
  email: string;
  phone?: string;
  address?: string;
  membership_type: 'standard' | 'premium' | 'student';
  membership_start: Date;
  membership_end?: Date | null;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

const MemberSchema = new Schema<IMember>({
  member_id: { type: String, required: true },
  full_name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String },
  address: { type: String },
  membership_type: { type: String, enum: ['standard', 'premium', 'student'], default: 'standard' },
  membership_start: { type: Date, default: Date.now },
  membership_end: { type: Date },
  is_active: { type: Boolean, default: true },
  created_at: { type: Date, default: Date.now },
  updated_at: { type: Date, default: Date.now },
});

MemberSchema.pre('save', function (next) {
  this.updated_at = new Date();
  next();
});

export const Member = mongoose.model<IMember>('Member', MemberSchema);