import dotenv from 'dotenv';

dotenv.config();

export const env = {
  PORT: process.env.PORT ? Number(process.env.PORT) : 4000,
  MONGODB_URI: process.env.MONGODB_URI || '',
  JWT_SECRET: process.env.JWT_SECRET || 'dev_jwt_secret_change_me',
  CORS_ORIGIN: process.env.CORS_ORIGIN || 'http://localhost:5173',
};