import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';

export function requireRole(roles: Array<'admin' | 'staff' | 'user'>) {
  return (req: AuthRequest, res: Response, next: NextFunction) => {
    const role = req.user?.role || 'user';
    if (!roles.includes(role as any)) {
      return res.status(403).json({ error: 'Forbidden: insufficient role' });
    }
    next();
  };
}