import dotenv from 'dotenv';
import mongoose from 'mongoose';
import { env } from '../config/env';
import { autoSeed } from '../utils/autoSeed';

dotenv.config();

async function run() {
  try {
    const MONGODB_URI = env.MONGODB_URI || process.env.MONGODB_URI || '';
    if (!MONGODB_URI) {
      console.error('MONGODB_URI not set; please configure .env');
      process.exit(1);
    }

    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB');

    // Force book seeding as requested; free image links are used (picsum)
    await autoSeed({ forceBooks: true });
    console.log('Sample data seeding complete (books forced)');
  } catch (err) {
    console.error('Seed failed', err);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
}

run();