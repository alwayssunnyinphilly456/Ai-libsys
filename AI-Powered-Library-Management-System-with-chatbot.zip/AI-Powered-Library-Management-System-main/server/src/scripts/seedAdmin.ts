import dotenv from 'dotenv';
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { env } from '../config/env';
import { User } from '../models/User';
import { Member } from '../models/Member';

dotenv.config();

async function run() {
  try {
    const MONGODB_URI = env.MONGODB_URI || process.env.MONGODB_URI || '';
    if (!MONGODB_URI) {
      console.error('MONGODB_URI not set; please configure .env');
      process.exit(1);
    }

    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB');

    const email = process.env.ADMIN_EMAIL || 'admin@example.com';
    const password = process.env.ADMIN_PASSWORD || 'Admin123!';
    const fullName = process.env.ADMIN_NAME || 'Admin User';

    let user = await User.findOne({ email });
    const passwordHash = await bcrypt.hash(password, 10);

    if (!user) {
      user = await User.create({ email, passwordHash, fullName, role: 'admin' });
      console.log(`Created admin user: ${email}`);
    } else {
      const update: Partial<{ role: 'admin' | 'staff' | 'user'; passwordHash: string }> = {};
      if (user.role !== 'admin') update.role = 'admin';
      if (process.env.ADMIN_PASSWORD) update.passwordHash = passwordHash;
      if (Object.keys(update).length) {
        user.set(update);
        await user.save();
        console.log(`Updated existing user: ${email} to admin role`);
      } else {
        console.log(`Admin user already exists: ${email}`);
      }
    }

    const existingMember = await Member.findOne({ email });
    if (!existingMember) {
      const memberId = `MEM${Date.now().toString().slice(-6)}`;
      await Member.create({
        member_id: memberId,
        full_name: fullName,
        email,
        membership_type: 'standard',
        membership_start: new Date(),
        is_active: true,
      });
      console.log(`Created member record for admin: ${memberId}`);
    } else {
      console.log('Member record already exists for admin');
    }

    console.log('Done. Use these credentials to sign in:');
    console.log(`Email: ${email}`);
    console.log(`Password: ${password}`);
  } catch (err) {
    console.error('Seed failed', err);
    process.exit(1);
  } finally {
    await mongoose.disconnect();
    process.exit(0);
  }
}

run();