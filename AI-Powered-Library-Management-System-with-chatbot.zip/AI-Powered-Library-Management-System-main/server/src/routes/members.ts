import { Router } from 'express';
import { listMembers, updateMember, toggleMemberStatus } from '../controllers/memberController';
import { authMiddleware } from '../middleware/auth';

const router = Router();

router.get('/', authMiddleware, listMembers);
router.put('/:id', authMiddleware, updateMember);
router.patch('/:id/toggle', authMiddleware, toggleMemberStatus);

export default router;