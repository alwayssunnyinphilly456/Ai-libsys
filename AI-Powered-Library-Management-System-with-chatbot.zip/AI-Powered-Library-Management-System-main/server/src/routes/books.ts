import { Router } from 'express';
import { listBooks, createBook, updateBook, deleteBook } from '../controllers/bookController';
import { authMiddleware } from '../middleware/auth';
import { requireRole } from '../middleware/roles';

const router = Router();

router.get('/', authMiddleware, listBooks);
router.post('/', authMiddleware, requireRole(['admin', 'staff']), createBook);
router.put('/:id', authMiddleware, requireRole(['admin', 'staff']), updateBook);
router.delete('/:id', authMiddleware, requireRole(['admin', 'staff']), deleteBook);

export default router;