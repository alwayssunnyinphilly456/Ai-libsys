import { Router } from 'express';
import { listTransactions, borrowBook, returnBook, approveBorrow } from '../controllers/transactionController';
import { authMiddleware } from '../middleware/auth';
import { requireRole } from '../middleware/roles';

const router = Router();

router.get('/', authMiddleware, listTransactions);
router.post('/borrow', authMiddleware, borrowBook);
router.post('/:id/approve', authMiddleware, requireRole(['admin', 'staff']), approveBorrow);
router.post('/:id/return', authMiddleware, returnBook);

export default router;