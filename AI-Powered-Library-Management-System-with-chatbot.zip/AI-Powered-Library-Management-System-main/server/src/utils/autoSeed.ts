import bcrypt from 'bcryptjs';
import { Book } from '../models/Book';
import { User } from '../models/User';
import { Member } from '../models/Member';
import { Transaction } from '../models/Transaction';

function randInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pick<T>(arr: T[]): T {
  return arr[randInt(0, arr.length - 1)];
}

// Add force flags to allow targeted reseeding
export async function autoSeed(options: { forceBooks?: boolean; forceUsers?: boolean; forceTransactions?: boolean } = {}) {
  const bookCount = await Book.countDocuments();
  const userCount = await User.countDocuments();
  const memberCount = await Member.countDocuments();
  const txnCount = await Transaction.countDocuments();

  const forceBooks = options.forceBooks === true || process.env.FORCE_SEED_BOOKS === 'true';
  const forceUsers = options.forceUsers === true || process.env.FORCE_SEED_USERS === 'true';
  const forceTxns = options.forceTransactions === true || process.env.FORCE_SEED_TRANSACTIONS === 'true';

  // Seed Books if none or forced
  if (forceBooks || bookCount === 0) {
    const categories = ['Technology', 'Science', 'Computer Science'];
    const authors = ['Donald Knuth', 'Robert Sedgewick', 'Thomas H. Cormen', 'Gayle Laakmann', 'Ian Goodfellow', 'Andrew Ng', 'Leslie Lamport', 'Barbara Liskov'];
    const publishers = ['MIT Press', 'Pearson', 'OReilly Media', 'Springer', 'Addison-Wesley'];

    const books = Array.from({ length: 100 }).map((_, i) => {
      const year = randInt(1985, new Date().getFullYear());
      const total = randInt(3, 10);
      const available = randInt(1, total);
      const titleVariants = [
        `Computer Science Handbook Vol ${i + 1}`,
        `Algorithms and Data Structures ${i + 1}`,
        `Operating Systems Deep Dive ${i + 1}`,
        `Distributed Systems Essentials ${i + 1}`,
        `Machine Learning Foundations ${i + 1}`,
        `Data Engineering Patterns ${i + 1}`,
      ];
      const title = pick(titleVariants);
      const isbn = `978-${randInt(1000000000, 1999999999)}`;
      // Free placeholder image links
      const cover = `https://picsum.photos/seed/book${i}/200/300`;

      return {
        isbn,
        title,
        author: pick(authors),
        publisher: pick(publishers),
        publication_year: year,
        category: pick(categories),
        total_copies: total,
        available_copies: available,
        cover_image: cover,
        description: `${title} — sample seeded book for testing.`,
      };
    });

    await Book.insertMany(books);
    console.log(`Seeded ${books.length} sample books${forceBooks ? ' (forced)' : ''}`);
  }

  // Seed Users/Members if only admin or none, or forced
  if (forceUsers || userCount <= 1 || memberCount < 10) {
    const desiredUsers = 12; // between 10 and 20
    const toCreate = forceUsers ? desiredUsers : Math.max(0, desiredUsers - Math.max(userCount - 1, 0));
    const createdUsers: { id: string; email: string }[] = [];

    for (let i = 0; i < toCreate; i++) {
      const idx = i + 1;
      const email = `user${idx}@example.com`;
      const fullName = `Sample User ${idx}`;
      const passwordHash = await bcrypt.hash('User123!', 10);

      const existing = await User.findOne({ email });
      if (existing && !forceUsers) {
        createdUsers.push({ id: (existing as any).id, email });
        continue;
      }

      const user = existing && forceUsers ? existing : await User.create({ email, passwordHash, fullName, role: 'user' });
      const memberId = `MEM${Date.now().toString().slice(-6)}${idx}`;
      const existingMember = await Member.findOne({ email });
      if (!existingMember) {
        await Member.create({
          member_id: memberId,
          full_name: fullName,
          email,
          membership_type: 'standard',
          membership_start: new Date(),
          is_active: true,
        });
      }
      createdUsers.push({ id: (user as any).id, email });
    }

    console.log(`Seeded ${createdUsers.length} sample users and members${forceUsers ? ' (forced)' : ''}`);
  }

  // Seed Transactions if none or forced
  const seededBooks = await Book.find();
  const seededMembers = await Member.find();

  if ((forceTxns || txnCount === 0) && seededBooks.length > 0 && seededMembers.length > 0) {
    const transactions = [] as any[];
    const sampleCount = 24; // some issued, some returned

    for (let i = 0; i < sampleCount; i++) {
      const book = pick(seededBooks.filter(b => b.available_copies > 0)) || pick(seededBooks);
      const member = pick(seededMembers);
      const now = new Date();
      const status = pick(['issued', 'returned']);
      const due = new Date(now.getTime() + randInt(3, 21) * 24 * 60 * 60 * 1000);

      const txn: any = {
        book_id: (book as any)._id.toString(),
        member_id: (member as any)._id.toString(),
        issued_by: 'system-seed',
        issue_date: now,
        due_date: due,
        status,
        fine_amount: 0,
      };

      if (status === 'issued') {
        if (book.available_copies > 0) {
          book.available_copies = book.available_copies - 1;
          await book.save();
        }
      } else {
        const returnDate = new Date(now.getTime() + randInt(1, 5) * 24 * 60 * 60 * 1000);
        txn.return_date = returnDate;
        const daysOverdue = Math.max(0, Math.floor((returnDate.getTime() - due.getTime()) / (1000 * 60 * 60 * 24)));
        txn.fine_amount = daysOverdue * 2;
      }

      transactions.push(txn);
    }

    await Transaction.insertMany(transactions);
    console.log(`Seeded ${transactions.length} sample transactions${forceTxns ? ' (forced)' : ''}`);
  }

  console.log('Auto-seed check complete');
}