/*
  # Library Management System Database Schema

  ## Overview
  Complete database schema for a modern library management system with AI analytics support.

  ## New Tables

  ### 1. `books`
  Core table for book inventory management
  - `id` (uuid, primary key) - Unique identifier
  - `isbn` (text, unique) - International Standard Book Number
  - `title` (text) - Book title
  - `author` (text) - Book author
  - `publisher` (text) - Publisher name
  - `publication_year` (integer) - Year of publication
  - `category` (text) - Book category/genre
  - `total_copies` (integer) - Total copies owned
  - `available_copies` (integer) - Currently available copies
  - `cover_image` (text) - URL to cover image
  - `description` (text) - Book description
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 2. `members`
  Library member/user profiles
  - `id` (uuid, primary key) - Links to auth.users
  - `member_id` (text, unique) - Human-readable member ID
  - `full_name` (text) - Member's full name
  - `email` (text, unique) - Contact email
  - `phone` (text) - Contact phone number
  - `address` (text) - Physical address
  - `membership_type` (text) - Type of membership (standard, premium, student)
  - `membership_start` (timestamptz) - Membership start date
  - `membership_end` (timestamptz) - Membership expiry date
  - `is_active` (boolean) - Active status
  - `created_at` (timestamptz) - Record creation timestamp
  - `updated_at` (timestamptz) - Last update timestamp

  ### 3. `transactions`
  Book borrowing and return records
  - `id` (uuid, primary key) - Unique identifier
  - `book_id` (uuid, foreign key) - References books table
  - `member_id` (uuid, foreign key) - References members table
  - `issued_by` (uuid) - Staff who issued the book
  - `issue_date` (timestamptz) - When book was issued
  - `due_date` (timestamptz) - Expected return date
  - `return_date` (timestamptz, nullable) - Actual return date
  - `status` (text) - Transaction status (issued, returned, overdue)
  - `fine_amount` (numeric) - Late return fine
  - `notes` (text) - Additional notes
  - `created_at` (timestamptz) - Record creation timestamp

  ### 4. `analytics_events`
  Events for AI-powered analytics and insights
  - `id` (uuid, primary key) - Unique identifier
  - `event_type` (text) - Type of event (book_issued, book_returned, member_joined, etc.)
  - `event_data` (jsonb) - Flexible event data storage
  - `member_id` (uuid, nullable) - Associated member
  - `book_id` (uuid, nullable) - Associated book
  - `created_at` (timestamptz) - Event timestamp

  ## Security (Row Level Security)

  ### RLS Policies
  - All tables have RLS enabled for data protection
  - Members can view their own data only
  - Authenticated users (staff) can manage all records
  - Public cannot access any data without authentication

  ## Indexes
  - Performance indexes on frequently queried columns
  - ISBN lookup optimization
  - Member ID lookup optimization
  - Transaction status filtering
  - Date range queries on analytics

  ## Important Notes
  1. Uses Supabase Auth for user management
  2. Automatic timestamp management with triggers
  3. Book availability automatically updated via triggers
  4. Fine calculation based on overdue days
  5. Analytics events captured automatically for AI insights
*/

-- Create books table
CREATE TABLE IF NOT EXISTS books (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  isbn text UNIQUE,
  title text NOT NULL,
  author text NOT NULL,
  publisher text,
  publication_year integer,
  category text NOT NULL DEFAULT 'General',
  total_copies integer NOT NULL DEFAULT 1,
  available_copies integer NOT NULL DEFAULT 1,
  cover_image text,
  description text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT available_copies_check CHECK (available_copies >= 0 AND available_copies <= total_copies)
);

-- Create members table
CREATE TABLE IF NOT EXISTS members (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  member_id text UNIQUE NOT NULL,
  full_name text NOT NULL,
  email text UNIQUE NOT NULL,
  phone text,
  address text,
  membership_type text NOT NULL DEFAULT 'standard',
  membership_start timestamptz DEFAULT now(),
  membership_end timestamptz,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT membership_type_check CHECK (membership_type IN ('standard', 'premium', 'student'))
);

-- Create transactions table
CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  book_id uuid REFERENCES books(id) ON DELETE CASCADE NOT NULL,
  member_id uuid REFERENCES members(id) ON DELETE CASCADE NOT NULL,
  issued_by uuid REFERENCES auth.users(id),
  issue_date timestamptz DEFAULT now(),
  due_date timestamptz NOT NULL,
  return_date timestamptz,
  status text NOT NULL DEFAULT 'issued',
  fine_amount numeric(10,2) DEFAULT 0,
  notes text,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT status_check CHECK (status IN ('issued', 'returned', 'overdue'))
);

-- Create analytics_events table
CREATE TABLE IF NOT EXISTS analytics_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  event_data jsonb DEFAULT '{}'::jsonb,
  member_id uuid REFERENCES members(id) ON DELETE SET NULL,
  book_id uuid REFERENCES books(id) ON DELETE SET NULL,
  created_at timestamptz DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_books_isbn ON books(isbn);
CREATE INDEX IF NOT EXISTS idx_books_category ON books(category);
CREATE INDEX IF NOT EXISTS idx_books_author ON books(author);
CREATE INDEX IF NOT EXISTS idx_members_member_id ON members(member_id);
CREATE INDEX IF NOT EXISTS idx_members_email ON members(email);
CREATE INDEX IF NOT EXISTS idx_transactions_status ON transactions(status);
CREATE INDEX IF NOT EXISTS idx_transactions_member_id ON transactions(member_id);
CREATE INDEX IF NOT EXISTS idx_transactions_book_id ON transactions(book_id);
CREATE INDEX IF NOT EXISTS idx_transactions_dates ON transactions(issue_date, due_date, return_date);
CREATE INDEX IF NOT EXISTS idx_analytics_events_type ON analytics_events(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_events_created_at ON analytics_events(created_at);

-- Enable Row Level Security
ALTER TABLE books ENABLE ROW LEVEL SECURITY;
ALTER TABLE members ENABLE ROW LEVEL SECURITY;
ALTER TABLE transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;

-- RLS Policies for books table
CREATE POLICY "Anyone authenticated can view books"
  ON books FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert books"
  ON books FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update books"
  ON books FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete books"
  ON books FOR DELETE
  TO authenticated
  USING (true);

-- RLS Policies for members table
CREATE POLICY "Members can view own profile"
  ON members FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Authenticated users can view all members"
  ON members FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert members"
  ON members FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Members can update own profile"
  ON members FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Authenticated users can update members"
  ON members FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete members"
  ON members FOR DELETE
  TO authenticated
  USING (true);

-- RLS Policies for transactions table
CREATE POLICY "Members can view own transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING (auth.uid() = member_id);

CREATE POLICY "Authenticated users can view all transactions"
  ON transactions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert transactions"
  ON transactions FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update transactions"
  ON transactions FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete transactions"
  ON transactions FOR DELETE
  TO authenticated
  USING (true);

-- RLS Policies for analytics_events table
CREATE POLICY "Authenticated users can view analytics"
  ON analytics_events FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert analytics"
  ON analytics_events FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_books_updated_at
  BEFORE UPDATE ON books
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_members_updated_at
  BEFORE UPDATE ON members
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Function to update book availability
CREATE OR REPLACE FUNCTION update_book_availability()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' AND NEW.status = 'issued' THEN
    UPDATE books SET available_copies = available_copies - 1 WHERE id = NEW.book_id;
  ELSIF TG_OP = 'UPDATE' AND OLD.status = 'issued' AND NEW.status = 'returned' THEN
    UPDATE books SET available_copies = available_copies + 1 WHERE id = NEW.book_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for book availability
CREATE TRIGGER transaction_book_availability
  AFTER INSERT OR UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION update_book_availability();

-- Function to create analytics events
CREATE OR REPLACE FUNCTION create_analytics_event()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    IF TG_TABLE_NAME = 'transactions' THEN
      INSERT INTO analytics_events (event_type, event_data, member_id, book_id)
      VALUES ('book_issued', jsonb_build_object('transaction_id', NEW.id), NEW.member_id, NEW.book_id);
    ELSIF TG_TABLE_NAME = 'members' THEN
      INSERT INTO analytics_events (event_type, event_data, member_id)
      VALUES ('member_joined', jsonb_build_object('membership_type', NEW.membership_type), NEW.id);
    END IF;
  ELSIF TG_OP = 'UPDATE' AND TG_TABLE_NAME = 'transactions' THEN
    IF OLD.status = 'issued' AND NEW.status = 'returned' THEN
      INSERT INTO analytics_events (event_type, event_data, member_id, book_id)
      VALUES ('book_returned', jsonb_build_object('transaction_id', NEW.id, 'fine_amount', NEW.fine_amount), NEW.member_id, NEW.book_id);
    END IF;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for analytics events
CREATE TRIGGER transaction_analytics_event
  AFTER INSERT OR UPDATE ON transactions
  FOR EACH ROW
  EXECUTE FUNCTION create_analytics_event();

CREATE TRIGGER member_analytics_event
  AFTER INSERT ON members
  FOR EACH ROW
  EXECUTE FUNCTION create_analytics_event();