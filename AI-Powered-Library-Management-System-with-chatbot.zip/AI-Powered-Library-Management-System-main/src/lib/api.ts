const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000';

function getToken() {
  return localStorage.getItem('accessToken');
}

async function request(path: string, options: RequestInit = {}) {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string> || {}),
  };
  const token = getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}${path}`, { ...options, headers });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

export const apiAuth = {
  async signIn(email: string, password: string) {
    const res = await request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    localStorage.setItem('accessToken', res.accessToken);
    return res;
  },
  async signUp(email: string, password: string, fullName: string) {
    const res = await request('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email, password, fullName }),
    });
    localStorage.setItem('accessToken', res.accessToken);
    return res;
  },
  async me() {
    return request('/auth/me');
  },
  async signOut() {
    localStorage.removeItem('accessToken');
  }
};

export const apiBooks = {
  list() { return request('/books'); },
  create(book: any) { return request('/books', { method: 'POST', body: JSON.stringify(book) }); },
  update(id: string, book: any) { return request(`/books/${id}`, { method: 'PUT', body: JSON.stringify(book) }); },
  remove(id: string) { return request(`/books/${id}`, { method: 'DELETE' }); },
};

export const apiMembers = {
  list() { return request('/members'); },
  update(id: string, member: any) { return request(`/members/${id}`, { method: 'PUT', body: JSON.stringify(member) }); },
  toggle(id: string) { return request(`/members/${id}/toggle`, { method: 'PATCH' }); },
};

export const apiTransactions = {
  list() { return request('/transactions'); },
  borrow(payload: any) { return request('/transactions/borrow', { method: 'POST', body: JSON.stringify(payload) }); },
  approve(id: string) { return request(`/transactions/${id}/approve`, { method: 'POST' }); },
  return(id: string) { return request(`/transactions/${id}/return`, { method: 'POST' }); },
};