import { useState, useEffect } from 'react';
import {
  TrendingUp,
  BookOpen,
  Users,
  ArrowLeftRight,
  DollarSign,
  Calendar,
  Award,
  AlertCircle,
} from 'lucide-react';
import { apiBooks, apiMembers, apiTransactions } from '../../lib/api';

interface AnalyticsData {
  totalBooks: number;
  totalMembers: number;
  activeTransactions: number;
  totalFines: number;
  popularBooks: { title: string; count: number }[];
  categoryDistribution: { category: string; count: number }[];
  recentActivity: { event_type: string; count: number; percentage: number }[];
  membershipTypes: { type: string; count: number }[];
  overdueBooks: number;
  booksIssuedThisMonth: number;
}

export function AIAnalyticsDashboard() {
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [insights, setInsights] = useState<string[]>([]);

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const fetchAnalytics = async () => {
    setLoading(true);

    try {
      const [booksRes, membersRes, transactionsRes] = await Promise.all([
        apiBooks.list(),
        apiMembers.list(),
        apiTransactions.list(),
      ]);

      const books = (booksRes.data || []) as any[];
      const members = (membersRes.data || []) as any[];
      const transactions = (transactionsRes.data || []) as any[];

      const activeTransactions = transactions.filter((t) => t.status === 'issued').length;
      const overdueBooks = transactions.filter((t) => t.status === 'overdue').length;
      const totalFines = transactions.reduce((sum, t) => sum + Number(t.fine_amount || 0), 0);

      const now = new Date();
      const currentMonth = now.getMonth();
      const currentYear = now.getFullYear();
      const booksIssuedThisMonth = transactions.filter((t) => {
        const d = new Date(t.issue_date);
        return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
      }).length;

      const bookMap = new Map<string, any>();
      books.forEach((b) => {
        const id = (b as any)._id || b.id;
        bookMap.set(id, b);
      });
      const bookIssueCount = transactions.reduce((acc, t) => {
        const book = bookMap.get(t.book_id);
        if (book) {
          acc[book.title] = (acc[book.title] || 0) + 1;
        }
        return acc;
      }, {} as Record<string, number>);

      const popularBooks = Object.entries(bookIssueCount)
        .sort(([, a], [, b]) => b - a)
        .slice(0, 5)
        .map(([title, count]) => ({ title, count }));

      const categoryCount = books.reduce((acc, book) => {
        acc[book.category] = (acc[book.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);

      const categoryDistribution = Object.entries(categoryCount).map(([category, count]) => ({
        category,
        count,
      }));

      // Build recent activity from transaction statuses
      const activityCount = transactions.reduce((acc, t) => {
        acc[t.status] = (acc[t.status] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      const totalEvents = Object.values(activityCount).reduce((a, b) => a + b, 0);
      const recentActivity = Object.entries(activityCount).map(([event_type, count]) => ({
        event_type,
        count,
        percentage: totalEvents ? Math.round((count / totalEvents) * 100) : 0,
      }));

      // Membership types distribution
      const membershipTypesCount = members.reduce((acc, m) => {
        acc[m.membership_type] = (acc[m.membership_type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      const membershipTypes = Object.entries(membershipTypesCount).map(([type, count]) => ({ type, count }));

      const nextAnalytics: AnalyticsData = {
        totalBooks: books.length,
        totalMembers: members.length,
        activeTransactions,
        totalFines,
        popularBooks,
        categoryDistribution,
        recentActivity,
        membershipTypes,
        overdueBooks,
        booksIssuedThisMonth,
      };

      setAnalytics(nextAnalytics);
      generateInsights(nextAnalytics);
    } catch (err) {
      // handle error
    }
    setLoading(false);
  };

  const generateInsights = (data: any) => {
    const insights: string[] = [];

    if (data.activeTransactions > 0) {
      const utilizationRate = (data.activeTransactions / data.totalBooks) * 100;
      insights.push(
        `Library utilization is at ${utilizationRate.toFixed(1)}% with ${
          data.activeTransactions
        } books currently issued.`
      );
    }

    if (data.overdueBooks > 0) {
      insights.push(
        `Alert: ${data.overdueBooks} book${
          data.overdueBooks > 1 ? 's are' : ' is'
        } overdue. Consider sending reminders to members.`
      );
    }

    if (data.booksIssuedThisMonth > 0) {
      insights.push(
        `${data.booksIssuedThisMonth} books issued this month, averaging ${(
          data.booksIssuedThisMonth / 30
        ).toFixed(1)} books per day.`
      );
    }

    if (data.popularBooks && data.popularBooks.length > 0) {
      insights.push(
        `Most popular book: "${data.popularBooks[0].title}" with ${data.popularBooks[0].count} issues. Consider acquiring similar titles.`
      );
    }

    if (data.totalMembers > 0 && data.activeTransactions > 0) {
      const avgBooksPerMember = (data.activeTransactions / data.totalMembers).toFixed(2);
      insights.push(
        `Average ${avgBooksPerMember} books per active member. Consider engagement programs if this is low.`
      );
    }

    setInsights(insights);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-slate-600">Analyzing library data...</p>
        </div>
      </div>
    );
  }

  if (!analytics) return null;

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">AI Analytics Dashboard</h2>
        <p className="text-slate-600">Smart insights and data-driven recommendations</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <BookOpen className="w-8 h-8 opacity-80" />
            <span className="text-3xl font-bold">{analytics.totalBooks}</span>
          </div>
          <p className="text-blue-100">Total Books</p>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <Users className="w-8 h-8 opacity-80" />
            <span className="text-3xl font-bold">{analytics.totalMembers}</span>
          </div>
          <p className="text-green-100">Active Members</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <ArrowLeftRight className="w-8 h-8 opacity-80" />
            <span className="text-3xl font-bold">{analytics.activeTransactions}</span>
          </div>
          <p className="text-orange-100">Active Loans</p>
        </div>

        <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between mb-2">
            <DollarSign className="w-8 h-8 opacity-80" />
            <span className="text-3xl font-bold">${analytics.totalFines.toFixed(0)}</span>
          </div>
          <p className="text-red-100">Total Fines</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-slate-900">AI-Powered Insights</h3>
          </div>
          <div className="space-y-3">
            {insights.map((insight, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-100"
              >
                <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-slate-700">{insight}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Award className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-slate-900">Most Popular Books</h3>
          </div>
          <div className="space-y-3">
            {analytics.popularBooks.map((book, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-bold text-sm">
                    {index + 1}
                  </div>
                  <p className="text-sm text-slate-700 line-clamp-1">{book.title}</p>
                </div>
                <span className="text-sm font-semibold text-slate-900 ml-2">
                  {book.count} issues
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-slate-900">Category Distribution</h3>
          </div>
          <div className="space-y-3">
            {analytics.categoryDistribution.map((cat, index) => {
              const percentage = (cat.count / analytics.totalBooks) * 100;
              return (
                <div key={index}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-slate-700">{cat.category}</span>
                    <span className="text-sm font-semibold text-slate-900">
                      {cat.count} ({percentage.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center gap-2 mb-4">
            <Users className="w-5 h-5 text-blue-600" />
            <h3 className="text-lg font-semibold text-slate-900">Membership Distribution</h3>
          </div>
          <div className="space-y-3">
            {analytics.membershipTypes.map((type, index) => {
              const percentage = (type.count / analytics.totalMembers) * 100;
              return (
                <div key={index}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-slate-700 capitalize">{type.type}</span>
                    <span className="text-sm font-semibold text-slate-900">
                      {type.count} ({percentage.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2">
                    <div
                      className="bg-green-600 h-2 rounded-full transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="mt-6 bg-gradient-to-br from-slate-900 to-slate-800 rounded-xl p-6 text-white">
        <h3 className="text-lg font-semibold mb-4">Quick Stats</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <p className="text-slate-400 text-sm mb-1">This Month</p>
            <p className="text-2xl font-bold">{analytics.booksIssuedThisMonth}</p>
            <p className="text-slate-400 text-xs">Books Issued</p>
          </div>
          <div>
            <p className="text-slate-400 text-sm mb-1">Overdue</p>
            <p className="text-2xl font-bold text-red-400">{analytics.overdueBooks}</p>
            <p className="text-slate-400 text-xs">Books</p>
          </div>
          <div>
            <p className="text-slate-400 text-sm mb-1">Availability</p>
            <p className="text-2xl font-bold text-green-400">
              {(
                ((analytics.totalBooks - analytics.activeTransactions) / analytics.totalBooks) *
                100
              ).toFixed(0)}
              %
            </p>
            <p className="text-slate-400 text-xs">Books Available</p>
          </div>
          <div>
            <p className="text-slate-400 text-sm mb-1">Categories</p>
            <p className="text-2xl font-bold">{analytics.categoryDistribution.length}</p>
            <p className="text-slate-400 text-xs">Different Types</p>
          </div>
        </div>
      </div>
    </div>
  );
}
