import { useState, useEffect } from 'react';
import { BookOpen, Users, TrendingUp, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import { apiBooks, apiMembers, apiTransactions } from '../../lib/api';

export function DashboardHome() {
  const [stats, setStats] = useState({
    totalBooks: 0,
    availableBooks: 0,
    totalMembers: 0,
    activeLoans: 0,
    overdueBooks: 0,
    recentTransactions: [] as any[],
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    setLoading(true);

    try {
      const [booksRes, membersRes, transactionsRes] = await Promise.all([
        apiBooks.list(),
        apiMembers.list(),
        apiTransactions.list(),
      ]);

      const books = (booksRes.data || []) as any[];
      const members = (membersRes.data || []) as any[];
      const transactions = (transactionsRes.data || []) as any[];

      const totalBooks = books.length;
      const availableBooks = books.reduce((sum, book) => sum + Number(book.available_copies || 0), 0);
      const activeLoans = transactions.filter((t) => t.status === 'issued').length;
      const overdueBooks = transactions.filter((t) => t.status === 'overdue').length;

      const bookMap = new Map<string, any>();
      books.forEach((b) => {
        const id = (b as any)._id || b.id;
        bookMap.set(id, b);
      });

      const memberMap = new Map<string, any>();
      members.forEach((m) => {
        const id = (m as any)._id || m.id;
        memberMap.set(id, m);
      });

      const enriched = transactions.map((t) => {
        const book = bookMap.get(t.book_id);
        const member = memberMap.get(t.member_id);
        return {
          ...t,
          books: book ? { title: book.title, author: book.author } : undefined,
          members: member ? { full_name: member.full_name } : undefined,
        };
      });

      setStats({
        totalBooks,
        availableBooks,
        totalMembers: members.length,
        activeLoans,
        overdueBooks,
        recentTransactions: enriched.slice(0, 5),
      });
    } catch (err) {
      // handle error
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="text-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Welcome to Library Dashboard</h1>
        <p className="text-slate-600">Here's what's happening in your library today</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <h3 className="text-2xl font-bold text-slate-900 mb-1">{stats.totalBooks}</h3>
          <p className="text-slate-600 text-sm">Total Books</p>
          <p className="text-xs text-slate-500 mt-2">{stats.availableBooks} available</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <TrendingUp className="w-5 h-5 text-green-500" />
          </div>
          <h3 className="text-2xl font-bold text-slate-900 mb-1">{stats.totalMembers}</h3>
          <p className="text-slate-600 text-sm">Active Members</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-900 mb-1">{stats.activeLoans}</h3>
          <p className="text-slate-600 text-sm">Active Loans</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
              <AlertTriangle className="w-6 h-6 text-red-600" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-slate-900 mb-1">{stats.overdueBooks}</h3>
          <p className="text-slate-600 text-sm">Overdue Books</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold text-slate-900 mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {stats.recentTransactions.map((transaction) => (
              <div
                key={(transaction as any)._id || transaction.id}
                className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg"
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    transaction.status === 'issued'
                      ? 'bg-blue-100'
                      : transaction.status === 'returned'
                      ? 'bg-green-100'
                      : 'bg-red-100'
                  }`}
                >
                  {transaction.status === 'issued' ? (
                    <Clock className="w-5 h-5 text-blue-600" />
                  ) : transaction.status === 'returned' ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <AlertTriangle className="w-5 h-5 text-red-600" />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-900">
                    {transaction.books?.title}
                  </p>
                  <p className="text-xs text-slate-500">
                    {transaction.members?.full_name} •{' '}
                    {new Date(transaction.issue_date).toLocaleDateString()}
                  </p>
                </div>
                <span
                  className={`text-xs px-2 py-1 rounded-full ${
                    transaction.status === 'issued'
                      ? 'bg-blue-100 text-blue-700'
                      : transaction.status === 'returned'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-red-100 text-red-700'
                  }`}
                >
                  {transaction.status}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-xl shadow-lg p-6 text-white">
          <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
          <div className="space-y-3">
            <button className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm rounded-lg p-4 text-left transition">
              <div className="flex items-center gap-3">
                <BookOpen className="w-5 h-5" />
                <div>
                  <p className="font-medium">Add New Book</p>
                  <p className="text-xs text-blue-100">Expand your collection</p>
                </div>
              </div>
            </button>
            <button className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm rounded-lg p-4 text-left transition">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5" />
                <div>
                  <p className="font-medium">Register Member</p>
                  <p className="text-xs text-blue-100">Add new library member</p>
                </div>
              </div>
            </button>
            <button className="w-full bg-white bg-opacity-20 hover:bg-opacity-30 backdrop-blur-sm rounded-lg p-4 text-left transition">
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5" />
                <div>
                  <p className="font-medium">Issue Book</p>
                  <p className="text-xs text-blue-100">Create new transaction</p>
                </div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {stats.overdueBooks > 0 && (
        <div className="mt-6 bg-red-50 border border-red-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
            <div>
              <h4 className="font-semibold text-red-900 mb-1">Attention Required</h4>
              <p className="text-sm text-red-700">
                You have {stats.overdueBooks} overdue book{stats.overdueBooks > 1 ? 's' : ''}. Consider sending reminders to members.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
