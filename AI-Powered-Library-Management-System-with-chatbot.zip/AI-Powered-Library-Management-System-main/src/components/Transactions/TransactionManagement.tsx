import { useState, useEffect } from 'react';
import { ArrowLeftRight, Plus, Search, CheckCircle, X, Calendar } from 'lucide-react';
import { apiTransactions, apiBooks, apiMembers } from '../../lib/api';
import { useAuth } from '../../contexts/AuthContext';

type Transaction = {
  _id?: string;
  id?: string;
  book_id: string;
  member_id: string;
  issued_by?: string | null;
  issue_date?: string;
  due_date: string;
  return_date?: string | null;
  status: 'requested' | 'issued' | 'returned' | 'overdue';
  fine_amount: number;
  notes?: string | null;
  books?: { title: string; author: string };
  members?: { full_name: string; member_id: string };
};

type Book = {
  _id?: string;
  id?: string;
  title: string;
  author: string;
  available_copies: number;
};

type Member = {
  _id?: string;
  id?: string;
  full_name: string;
  member_id: string;
};

export function TransactionManagement() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [formData, setFormData] = useState({
    book_id: '',
    member_id: '',
    due_date: '',
    notes: '',
  });

  const { user } = useAuth();
  const isAdminOrStaff = user?.role === 'admin' || user?.role === 'staff';
  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);

    try {
      const [transactionsRes, booksRes, membersRes] = await Promise.all([
        apiTransactions.list(),
        apiBooks.list(),
        apiMembers.list(),
      ]);

      const transactions = transactionsRes.data as Transaction[];
      const books = booksRes.data as Book[];
      const members = membersRes.data as Member[];

      const bookMap = new Map<string, Book>();
      books.forEach(b => {
        const id = (b as any)._id || (b.id as string);
        bookMap.set(id, b);
      });

      const memberMap = new Map<string, Member>();
      members.forEach(m => {
        const id = (m as any)._id || (m.id as string);
        memberMap.set(id, m);
      });

      const enriched = transactions.map(t => {
        const book = bookMap.get(t.book_id);
        const member = memberMap.get(t.member_id);
        return {
          ...t,
          books: book ? { title: (book as any).title, author: (book as any).author } : undefined,
          members: member ? { full_name: (member as any).full_name, member_id: (member as any).member_id } : undefined,
        };
      });

      setTransactions(enriched);
      setBooks(books);
      setMembers(members);
    } catch (err) {
      // handle error
    }

    setLoading(false);
  };

  const handleIssueBook = async (e: React.FormEvent) => {
    e.preventDefault();

    const dueDate = new Date(formData.due_date);
    // const { data: userData } = await supabase.auth.getUser();

    try {
      await apiTransactions.borrow({
        book_id: formData.book_id,
        member_id: formData.member_id,
        issued_by: undefined,
        due_date: dueDate.toISOString(),
        notes: formData.notes || null,
      });
      fetchData();
      closeModal();
    } catch (err) {
      // handle error
    }
  };

  const handleReturnBook = async (transaction: Transaction) => {
    try {
      const id = (transaction as any)._id || (transaction.id as string);
      await apiTransactions.return(id);
      fetchData();
    } catch (err) {
      // handle error
    }
  };

  const handleApprove = async (transaction: Transaction) => {
    try {
      const id = (transaction as any)._id || (transaction.id as string);
      await apiTransactions.approve(id);
      fetchData();
    } catch (err) {
      // handle error
    }
  };

  const openModal = () => {
    setFormData({
      book_id: '',
      member_id: '',
      due_date: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      notes: '',
    });
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const filteredTransactions = transactions.filter((transaction) => {
    const matchesSearch =
      transaction.books?.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.members?.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.members?.member_id.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = selectedStatus === 'all' || transaction.status === selectedStatus;

    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'issued':
        return 'bg-blue-100 text-blue-700';
      case 'returned':
        return 'bg-green-100 text-green-700';
      case 'overdue':
        return 'bg-red-100 text-red-700';
      default:
        return 'bg-slate-100 text-slate-700';
    }
  };

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Transaction Management</h2>
        <p className="text-slate-600">Track book issues and returns</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search by book title, member name, or ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="requested">Requested</option>
            <option value="issued">Issued</option>
            <option value="returned">Returned</option>
            <option value="overdue">Overdue</option>
          </select>
          <button
            onClick={openModal}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition whitespace-nowrap"
          >
            <Plus className="w-5 h-5" />
            Issue Book
          </button>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Book</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Member</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Issue Date</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Due Date</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Status</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Fine</th>
                  <th className="text-left py-3 px-4 font-semibold text-slate-700">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredTransactions.map((transaction) => (
                  <tr key={(transaction as any)._id || transaction.id} className="border-b border-slate-200">
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium text-slate-900">{transaction.books?.title}</p>
                        <p className="text-sm text-slate-500">{transaction.books?.author}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div>
                        <p className="font-medium text-slate-900">
                          {transaction.members?.full_name}
                        </p>
                        <p className="text-sm text-slate-500">{transaction.members?.member_id}</p>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-sm text-slate-600">
                      {transaction.issue_date ? new Date(transaction.issue_date).toLocaleDateString() : '-'}
                    </td>
                    <td className="py-3 px-4 text-sm text-slate-600">
                      {new Date(transaction.due_date).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(
                        transaction.status
                      )}`}>
                        {transaction.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-sm text-slate-600">
                      ${transaction.fine_amount.toFixed(2)}
                    </td>
                    <td className="py-3 px-4">
                      {transaction.status === 'requested' && isAdminOrStaff && (
                        <button
                          onClick={() => handleApprove(transaction)}
                          className="text-blue-600 hover:bg-blue-50 p-2 rounded transition flex items-center gap-1"
                        >
                          <CheckCircle className="w-4 h-4" />
                          <span className="text-sm">Approve</span>
                        </button>
                      )}
                      {transaction.status === 'issued' && (
                        <button
                          onClick={() => handleReturnBook(transaction)}
                          className="text-green-600 hover:bg-green-50 p-2 rounded transition flex items-center gap-1"
                        >
                          <CheckCircle className="w-4 h-4" />
                          <span className="text-sm">Return</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-md w-full">
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <h3 className="text-xl font-bold text-slate-900">Issue Book</h3>
              <button
                onClick={closeModal}
                className="text-slate-400 hover:text-slate-600 transition"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleIssueBook} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Select Book *
                </label>
                <select
                  required
                  value={formData.book_id}
                  onChange={(e) => setFormData({ ...formData, book_id: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Choose a book</option>
                  {books.map((book) => (
                    <option key={(book as any)._id || book.id} value={(book as any)._id || book.id}>
                       {book.title} - {book.author} (Available: {book.available_copies})
                     </option>
                   ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Select Member *
                </label>
                <select
                  required
                  value={formData.member_id}
                  onChange={(e) => setFormData({ ...formData, member_id: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Choose a member</option>
                  {members.map((member) => (
                    <option key={(member as any)._id || member.id} value={(member as any)._id || member.id}>
                       {member.full_name} ({member.member_id})
                     </option>
                   ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">
                  Due Date *
                </label>
                <input
                  type="date"
                  required
                  value={formData.due_date}
                  onChange={(e) => setFormData({ ...formData, due_date: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Notes</label>
                <textarea
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  type="button"
                  onClick={closeModal}
                  className="flex-1 px-4 py-2 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                >
                  Issue Book
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
