export type FAQ = { question: string; answer: string };

export const FAQs: FAQ[] = [
  { question: "How do I issue a book?", answer:
`1. Go to the Books page.
2. Search or click the book you want to issue.
3. Click "Issue" and select the user.
4. Confirm — the book will appear in Issued Books / History.` },
  { question: "How do I return a book?", answer:
`1. Open Issued Books or the User's issued list.
2. Find the book and click "Return".
3. Confirm the return — the book stock will update.` },
  { question: "How do I search for books?", answer:
`Use the search box on the Books page. You can search by title, author, ISBN or tags. Filters (category/status) are available above the list.` },
  { question: "How do I add a new book?", answer:
`1. Go to Book Management.
2. Click "Add Book" or the + button.
3. Fill required fields (title, author, ISBN, quantity).
4. Save — the book will appear in the catalog.` },
  { question: "How do I manage users?", answer:
`Go to Users / Members. You can add, edit or remove users. Assign roles (admin/member) to control permissions.` },
  { question: "How do I view issued history?", answer:
`Go to Issued History or Reports. You can filter by user, book, and date range.` },
  { question: "Who can access admin features?", answer:
`Only users with the Admin role can access Book Management, User Management, and Analytics pages.` },
  { question: "Where are analytics shown?", answer:
`Open the Analytics / Dashboard page. It shows issued counts, popular books, and other AI analytics if enabled.` },
  { question: "What should I do if something breaks?", answer:
`Check the server console for errors. Ensure the backend is running (server folder). If it's a UI issue, open browser console and report the error.` }
];
