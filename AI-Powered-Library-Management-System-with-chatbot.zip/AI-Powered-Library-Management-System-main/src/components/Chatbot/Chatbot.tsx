import React, { useState, useRef, useEffect } from 'react';
import './chatbot.css';
import { FAQs } from './chatbotData';

type Message = { from: 'user' | 'bot'; text: string };

const Chatbot: React.FC = () => {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { from: 'bot', text: 'Hi! I can help with the features of this Library Management System. Try the suggested questions below.' }
  ]);
  const [input, setInput] = useState('');
  const boxRef = useRef<HTMLDivElement|null>(null);

  useEffect(() => {
    if (open && boxRef.current) {
      const el = boxRef.current.querySelector('.chatbot-messages');
      if (el) el.scrollTop = el.scrollHeight;
    }
  }, [messages, open]);

  const send = (text: string) => {
    if (!text.trim()) return;
    const userMsg: Message = { from: 'user', text: text.trim() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    // simple rule-based reply: try to find FAQ match by keywords or exact question
    const q = text.toLowerCase();
    let found = FAQs.find(f => f.question.toLowerCase() === q);
    if (!found) {
      // find by keyword presence
      found = FAQs.find(f => {
        const words = f.question.toLowerCase().split(/\W+/);
        return words.some(w => w && q.includes(w));
      });
    }
    const botReply = found ? found.answer : "Sorry — I only answer questions about this project's features. Try: 'How do I issue a book?' or pick a suggestion.";
    const botMsg: Message = { from: 'bot', text: botReply };
    setTimeout(() => setMessages(prev => [...prev, botMsg]), 400);
  };

  return (
    <div className="chatbot-root" aria-live="polite">
      {!open && (
        <button
          className="chatbot-button"
          aria-label="Open help chat"
          title="Help"
          onClick={() => setOpen(true)}
        >
          ?
        </button>
      )}

      {open && (
        <div className="chatbot-window" role="dialog" aria-label="Feature help bot">
          <div style={{position:'relative'}}>
            <div className="chatbot-header">Project Helper — LMS
              <button className="chatbot-close" onClick={() => setOpen(false)}>×</button>
            </div>
          </div>

          <div className="chatbot-messages" ref={boxRef}>
            {messages.map((m, i) => (
              <div key={i} className={m.from === 'user' ? 'chatbot-message user' : 'chatbot-message bot'}>
                <div style={{whiteSpace:'pre-wrap'}}>{m.text}</div>
              </div>
            ))}
          </div>

          <div className="chatbot-suggestions" role="list">
            {FAQs.slice(0,6).map((f, i) => (
              <button key={i} className="chatbot-suggestion" onClick={() => send(f.question)}>{f.question}</button>
            ))}
          </div>

          <div className="chatbot-input">
            <input
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === 'Enter') send(input); }}
              placeholder="Ask about a feature (e.g., 'How to add a book?')"
              aria-label="Type a question"
            />
            <button onClick={() => send(input)} className="chatbot-suggestion">Send</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Chatbot;
