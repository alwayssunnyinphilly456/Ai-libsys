import { useState, useEffect } from 'react';
import { BookOpen, Plus, Search, Edit, Trash2, X } from 'lucide-react';
import { apiBooks, apiTransactions } from '../../lib/api';
import { useAuth } from '../../contexts/AuthContext';

type Book = {
  _id?: string;
  id?: string;
  isbn?: string | null;
  title: string;
  author: string;
  publisher?: string | null;
  publication_year?: number | null;
  category: string;
  total_copies: number;
  available_copies: number;
  cover_image?: string | null;
  description?: string | null;
  created_at?: string;
  updated_at?: string;
};

export function BookManagement() {
  const [books, setBooks] = useState<Book[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [showModal, setShowModal] = useState<boolean>(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [coverPreview, setCoverPreview] = useState<string>('');
  const [coverError, setCoverError] = useState<string>('');
  const [formData, setFormData] = useState<any>({
    isbn: '',
    title: '',
    author: '',
    publisher: '',
    publication_year: new Date().getFullYear(),
    category: 'Computer Science',
    total_copies: 1,
    available_copies: 1,
    cover_image: '',
    description: '',
  });

  const { user } = useAuth();
  const isAdminOrStaff = user?.role === 'admin' || user?.role === 'staff';

  const handleCoverUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate image type
    if (!file.type.startsWith('image/')) {
      setCoverError('Please upload a valid image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      setFormData({ ...formData, cover_image: dataUrl });
      setCoverPreview(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    setLoading(true);
    try {
      const { data } = await apiBooks.list();
      setBooks(data);
    } catch (err) {
      // handle error if needed
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingBook) {
        const id = (editingBook as any)._id || (editingBook.id as string);
        await apiBooks.update(id, formData);
        fetchBooks();
        closeModal();
      } else {
        await apiBooks.create(formData);
        fetchBooks();
        closeModal();
      }
    } catch (err) {
      // handle error if needed
    }
  };

  const handleDelete = async (book: Book) => {
    try {
      if (confirm('Are you sure you want to delete this book?')) {
        const id = (book as any)._id || (book.id as string);
        await apiBooks.remove(id);
        fetchBooks();
      }
    } catch (err) {
      // handle error
    }
  };

  const handleRequest = async (book: Book) => {
    try {
      const id = (book as any)._id || (book.id as string);
      await apiTransactions.borrow({ book_id: id });
      alert('Borrow request submitted. Staff/Admin will approve.');
    } catch (err: any) {
      alert(err?.message || 'Failed to request book');
    }
  };

  const openModal = (book?: Book) => {
    if (book) {
      setEditingBook(book);
      setFormData({
        isbn: book.isbn || '',
        title: book.title,
        author: book.author,
        publisher: book.publisher || '',
        publication_year: book.publication_year || new Date().getFullYear(),
        category: book.category,
        total_copies: book.total_copies,
        available_copies: book.available_copies,
        cover_image: book.cover_image || '',
        description: book.description || '',
      });
      setCoverPreview(book.cover_image || '');
      setCoverError('');
    } else {
      setEditingBook(null);
      setFormData({
        isbn: '',
        title: '',
        author: '',
        publisher: '',
        publication_year: new Date().getFullYear(),
        category: 'Computer Science',
        total_copies: 1,
        available_copies: 1,
        cover_image: '',
        description: '',
      });
      setCoverPreview('');
      setCoverError('');
    }
    setShowModal(true);
  };

  const closeModal = () => setShowModal(false);

  const filteredBooks = books.filter(
    (book) =>
      book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
      book.isbn?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Book Management</h2>
        <p className="text-slate-600">Manage your library's book collection</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search books by title, author, or ISBN..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          {isAdminOrStaff && (
            <button
              onClick={() => openModal()}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition"
            >
              <Plus className="w-5 h-5" />
              Add Book
            </button>
          )}
        </div>

        {loading && (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        )}
        {!loading && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredBooks.map((book) => (
                <div
                  key={book.id || book._id}
                  className="border border-slate-200 rounded-lg p-4 hover:shadow-md transition"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex gap-3 items-start">
                      {book.cover_image && (
                        <img
                          src={book.cover_image}
                          alt={`${book.title} cover`}
                          className="w-16 h-24 object-cover rounded border border-slate-200"
                        />
                      )}
                      <div className="flex-1">
                        <h3 className="font-semibold text-slate-900 mb-1">{book.title}</h3>
                        <p className="text-sm text-slate-600">by {book.author}</p>
                      </div>
                      <div className="flex gap-2">
                        {isAdminOrStaff ? (
                          <>
                            <button
                              onClick={() => openModal(book)}
                              className="text-blue-600 hover:bg-blue-50 p-2 rounded transition"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDelete(book)}
                              className="text-red-600 hover:bg-red-50 p-2 rounded transition"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </>
                        ) : (
                          <button
                            onClick={() => handleRequest(book)}
                            className="text-green-600 hover:bg-green-50 p-2 rounded transition"
                          >
                            Request
                          </button>
                        )}
                      </div>
                    </div>
                    <div className="space-y-1 text-sm">
                      <p className="text-slate-600">
                        <span className="font-medium">ISBN:</span> {book.isbn || 'N/A'}
                      </p>
                      <p className="text-slate-600">
                        <span className="font-medium">Category:</span> {book.category}
                      </p>
                      <div className="flex justify-between pt-2 border-t border-slate-100">
                        <span className="text-slate-600">Available: {book.available_copies}</span>
                        <span className="text-slate-600">Total: {book.total_copies}</span>
                      </div>
                    </div>
                  </div>
                  </div>
                ))}
            </div>
          </>
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between p-6 border-b border-slate-200">
              <h3 className="text-xl font-bold text-slate-900">
                {editingBook ? 'Edit Book' : 'Add New Book'}
              </h3>
              <button
                onClick={closeModal}
                className="text-slate-400 hover:text-slate-600 transition"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700">Title</label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Author</label>
                  <input
                    type="text"
                    value={formData.author}
                    onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Publisher</label>
                  <input
                    type="text"
                    value={formData.publisher}
                    onChange={(e) => setFormData({ ...formData, publisher: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Publication Year</label>
                  <input
                    type="number"
                    value={formData.publication_year}
                    onChange={(e) => setFormData({ ...formData, publication_year: Number(e.target.value) })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Category</label>
                  <input
                    type="text"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Total Copies</label>
                  <input
                    type="number"
                    value={formData.total_copies}
                    onChange={(e) => setFormData({ ...formData, total_copies: Number(e.target.value) })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min={1}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700">Available Copies</label>
                  <input
                    type="number"
                    value={formData.available_copies}
                    onChange={(e) => setFormData({ ...formData, available_copies: Number(e.target.value) })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    min={0}
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700">ISBN</label>
                  <input
                    type="text"
                    value={formData.isbn}
                    onChange={(e) => setFormData({ ...formData, isbn: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700">Cover Image</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleCoverUpload}
                    className="mt-1 w-full"
                  />
                  {coverError && <p className="text-red-600 text-sm mt-1">{coverError}</p>}
                  {coverPreview && (
                    <img src={coverPreview} alt="Cover preview" className="mt-2 w-32 h-48 object-cover rounded border" />
                  )}
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-700">Description</label>
                  <textarea
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="mt-1 w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    rows={4}
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700"
                >
                  {editingBook ? 'Save Changes' : 'Create Book'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
