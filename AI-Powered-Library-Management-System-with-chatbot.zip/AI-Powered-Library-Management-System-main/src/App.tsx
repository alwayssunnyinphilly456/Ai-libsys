import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LoginForm } from './components/Auth/LoginForm';
import { DashboardLayout } from './components/Dashboard/DashboardLayout';
import { DashboardHome } from './components/Dashboard/DashboardHome';
import { BookManagement } from './components/Books/BookManagement';
import { MemberManagement } from './components/Members/MemberManagement';
import { TransactionManagement } from './components/Transactions/TransactionManagement';
import { AIAnalyticsDashboard } from './components/Analytics/AIAnalyticsDashboard';

function AppContent() {
  const { user, loading } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <LoginForm />;
  }

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <DashboardHome />;
      case 'books':
        return <BookManagement />;
      case 'members':
        return <MemberManagement />;
      case 'transactions':
        return <TransactionManagement />;
      case 'analytics':
        return <AIAnalyticsDashboard />;
      default:
        return <DashboardHome />;
    }
  };

  return (
    <DashboardLayout currentView={currentView} onViewChange={setCurrentView}>
      {renderView()}
    </DashboardLayout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;


// --- Chatbot portal mount (injected by assistant) ---
import ReactDOM from 'react-dom';
try {
  if (typeof document !== 'undefined') {
    const elId = 'assistant-chatbot-root';
    if (!document.getElementById(elId)) {
      const d = document.createElement('div');
      d.id = elId;
      document.body.appendChild(d);
    }
    const root = document.getElementById('assistant-chatbot-root');
    if (root) {
      const Chatbot = require('./components/Chatbot/Chatbot').default;
      ReactDOM.render(React.createElement(Chatbot), root);
    }
  }
} catch(e) {
  /* ignore during SSR/build */
}
